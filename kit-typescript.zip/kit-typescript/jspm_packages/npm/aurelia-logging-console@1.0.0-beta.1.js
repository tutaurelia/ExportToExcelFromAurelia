define(["npm:aurelia-logging-console@1.0.0-beta.1/aurelia-logging-console"], function(main) {
  return main;
});