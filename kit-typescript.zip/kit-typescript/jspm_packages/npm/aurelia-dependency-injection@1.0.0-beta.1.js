define(["npm:aurelia-dependency-injection@1.0.0-beta.1/aurelia-dependency-injection"], function(main) {
  return main;
});