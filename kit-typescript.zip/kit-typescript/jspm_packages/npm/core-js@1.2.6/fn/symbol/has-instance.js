/* */ 
module.exports = require('../../modules/$.wks')('hasInstance');
