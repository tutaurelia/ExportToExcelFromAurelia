/* */ 
module.exports = require('../../modules/$.wks')('isConcatSpreadable');
