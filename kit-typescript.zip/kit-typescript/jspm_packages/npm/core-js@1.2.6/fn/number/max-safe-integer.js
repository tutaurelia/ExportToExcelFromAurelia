/* */ 
require('../../modules/es6.number.max-safe-integer');
module.exports = 0x1fffffffffffff;
