/* */ 
var $ = require('../../modules/$');
module.exports = function defineProperties(T, D) {
  return $.setDescs(T, D);
};
