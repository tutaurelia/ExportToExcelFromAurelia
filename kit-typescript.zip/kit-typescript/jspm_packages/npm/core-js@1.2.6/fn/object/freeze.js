/* */ 
require('../../modules/es6.object.freeze');
module.exports = require('../../modules/$.core').Object.freeze;
