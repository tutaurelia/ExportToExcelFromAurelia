/* */ 
require('../../modules/es6.object.seal');
module.exports = require('../../modules/$.core').Object.seal;
