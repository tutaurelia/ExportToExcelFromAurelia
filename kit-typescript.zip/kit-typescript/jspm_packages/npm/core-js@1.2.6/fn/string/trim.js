/* */ 
require('../../modules/es6.string.trim');
module.exports = require('../../modules/$.core').String.trim;
