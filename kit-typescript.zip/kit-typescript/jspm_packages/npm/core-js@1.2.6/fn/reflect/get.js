/* */ 
require('../../modules/es6.reflect.get');
module.exports = require('../../modules/$.core').Reflect.get;
