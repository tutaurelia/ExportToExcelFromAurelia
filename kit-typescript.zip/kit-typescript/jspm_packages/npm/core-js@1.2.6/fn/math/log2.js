/* */ 
require('../../modules/es6.math.log2');
module.exports = require('../../modules/$.core').Math.log2;
