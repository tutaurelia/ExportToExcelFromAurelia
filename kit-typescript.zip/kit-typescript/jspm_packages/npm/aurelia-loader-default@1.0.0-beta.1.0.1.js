define(["npm:aurelia-loader-default@1.0.0-beta.1.0.1/aurelia-loader-default"], function(main) {
  return main;
});